Worm Locker2.0
-----------------

Creator: Clutter Tech
Created in: C#
Type: Trojan-Ransom.Win32
Support OS: win7/win8/win10

-----------------

My youtube channel: https://www.youtube.com/channel/UC9keh4wDjXFyiRhHDE_h90Q?view_as=subscriber

For 20 likes I will publish the source code :D